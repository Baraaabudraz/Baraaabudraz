<?php

namespace App\Models;

use Egulias\EmailValidator\Parser\Comment;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Resturant extends Model
{
    use HasFactory;
    protected $fillable = ['name' , 'image' , 'city_id' , 'status' ,'slug'];
    public function City()
    {
        return $this->belongsTo(City::class , 'city_id' , 'id');
    }


    public function Meals()
    {
        return $this->hasMany(Meal::class , 'resturant_id' , 'id');
    }
    public function comment()

    {
        return $this->hasMany(Comment::class,'resturant_id','id');
    }
    public function rating(){
        return $this->hasMany(Review::class,'resturant_id','id');
    }
}
