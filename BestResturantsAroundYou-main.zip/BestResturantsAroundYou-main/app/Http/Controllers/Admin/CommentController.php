<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use App\Models\Resturant;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function store(Request $request,$id)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'comment' => 'required',
        ]);
        $resturant=Resturant::find($id);
            if ($resturant){
                Comment::create([

                    'resturant_id'=>$resturant->id,
                    'name'=>$request->name,
                    'email'=>$request->email,
                    'comment'=>$request->comment,
                    'review'=>$request->review,

                ]);
                return redirect()->back()->with('comment-created','test');
            }



    }
//
//    public function rating(Request $request,$id){
//        $ratings=Review::with('resturant')->where('returant_id',$id)->get();
//        $ratingsSum=Comment::query()->where('resturant_id',$id)->sum('review');
//        $ratingsCount=Review::where('resturant_id',$id)->count();
//        if ($ratingsCount>0){
//            $avgRating=round($ratingsSum/$ratingsCount,2);
//            $avgStarRating=round($ratingsSum/$ratingsCount);
//        }else{
//            $avgRating=0;
//            $avgStarRating=0;
//        }
//
//        return view('website.resturant-product',compact('ratings','avgRating','avgStarRating'));




}
