<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\City;
use App\Models\Comment;
use App\Models\Meal;
use App\Models\Resturant;
use App\Models\Review;
use Illuminate\Http\Request;

class FrontEndController extends Controller
{
    public  function ShowProductsOfResturant($id)

    {

        $resturant = Resturant::with('Meals')->where('id' , $id)->first() ;
        $comments = Comment::query()->where('resturant_id',$id)->get();

        $ratingsSum = Comment::query()->where('resturant_id',$id)->sum('review');
        $ratingsCount = $comments->count();
        if ($ratingsCount > 0){
            $avgRating=round($ratingsSum/$ratingsCount,2);
            $avgStarRating=round($ratingsSum/$ratingsCount);
        }else{
            $avgRating=0;
            $avgStarRating=0;
        }


        return view('website.resturant-product' , compact('resturant','comments','avgRating','avgStarRating'));
    }

    public  function ShowProduct($id)
    {
        $meal = Meal::with('restaurant')->where('id' , $id)->first() ;
        return view('website.meal-details' , compact('meal'));
    }

    public  function ShowResturantsOfCity($id)
    {
        $resturant = Resturant::query()->where('city_id',$id)->get();
        return view('website.city-resturant' , compact('resturant'));
    }



}
