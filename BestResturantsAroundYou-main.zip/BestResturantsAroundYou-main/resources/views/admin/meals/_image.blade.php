<div class="img-thumbnail" style="background-image: url({{asset('storage/' .$model->image)}}) ; height: 75px; background-size:cover">

</div>