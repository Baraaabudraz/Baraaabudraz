<tr>
    
    <a href="{{route('meals.edit' , $model->id)}}" class="btn btn-info"><i class="fa fa-lg fa-edit"></i></a>
    <a href="{{route('meals.destroy' , $model->id)}}" class="btn btn-danger"><i class="fa fa-lg fa-trash"></i></a>
</tr>