<?php
return [
    'name'=> 'الاسم' ,
    'image'=> 'الصورة' ,
    'description'=> 'الوصف' ,
    'usage'=> 'الاستخدام' ,
    'size'=> 'الحجم' ,
    'price'=> 'السعر',
    'discount'=> 'الخصم',
    'qr_code'=> 'كود كيو أر',
    'status'=> 'الحالة',
    'offer_expired'=> 'تاريخ انتهاء الصلاحية',
    'categories'=> 'القسم'  ,
    'brands'=> 'الماركة',
    'resturants'=> 'المطعم' ,
    'cities'=> 'المدن'
];