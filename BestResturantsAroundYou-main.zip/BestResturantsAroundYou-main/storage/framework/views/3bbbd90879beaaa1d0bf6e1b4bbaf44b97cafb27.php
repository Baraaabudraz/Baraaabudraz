<?php $__env->startSection('styles'); ?>
    <style>
        .image img {
            height: 200px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="hero-area overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-12">
                    <div class="hero-text text-center">

                        <div class="section-heading">
                            <h2 class="wow fadeInUp" data-wow-delay=".3s">مرحبا بك في كلاسي</h2>
                            <p class="wow fadeInUp" data-wow-delay=".5s">اكتشف مطعمك المناسب من خلال رؤية عروضنا ،
                                وجباتنا المميزة</p>
                        </div>


                        <div class="search-form wow fadeInUp" data-wow-delay=".7s">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-12 p-0">
                                    <div class="search-btn button">
                                        <button class="btn"><i class="lni lni-search-alt"></i>
                                            بحث</button>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-12 p-0">
                                    <div class="search-input">
                                        <label for="keyword"><i class="lni lni-search-alt theme-color"></i></label>
                                        <input type="text" name="keyword" id="keyword" placeholder="كلمة مفتاحية">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-12 p-0">
                                    <div class="search-input">
                                        <label for="category"><i class="lni lni-grid-alt theme-color"></i></label>
                                        <select name="category" id="category">
                                            <option value="none" selected disabled>اقسامنا</option>
                                            <option value="none">مطاعم</option>
                                            <option value="none">وجبات</option>
                                            <option value="none">عروض</option>
                                            <option value="none">Furniture</option>
                                            <option value="none">Fashion</option>
                                            <option value="none">Jobs</option>
                                            <option value="none">Real Estate</option>
                                            <option value="none">Animals</option>
                                            <option value="none">Education</option>
                                            <option value="none">Matrimony</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-12 p-0">
                                    <div class="search-input">
                                        <label for="location"><i class="lni lni-map-marker theme-color"></i></label>
                                        <select name="location" id="location">
                                            <option value="none" selected disabled>موقع </option>
                                            <option value="none">New York</option>
                                            <option value="none">California</option>
                                            <option value="none">Washington</option>
                                            <option value="none">Birmingham</option>
                                            <option value="none">Chicago</option>
                                            <option value="none">Phoenix</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="categories">
        <div class="container">
            <div class="cat-inner">
                <div class="row">
                    <div class="col-12 p-0">
                        <div class="category-slider">

                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/car.svg')); ?>" alt="#">
                                </div>
                                <h3>اقسامنا</h3>
                                <h5 class="total">35</h5>
                            </a>


                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/laptop.svg')); ?>" alt="#">
                                </div>
                                <h3>مطاعمنا</h3>
                                <h5 class="total">22</h5>
                            </a>


                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/matrimony.svg')); ?>" alt="#">
                                </div>
                                <h3>وجباتنا</h3>
                                <h5 class="total">55</h5>
                            </a>


                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/furniture.svg')); ?>" alt="#">
                                </div>
                                <h3>Furnitures</h3>
                                <h5 class="total">21</h5>
                            </a>


                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/jobs.svg')); ?>" alt="#">
                                </div>
                                <h3>Jobs</h3>
                                <h5 class="total">44</h5>
                            </a>


                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/real-estate.svg')); ?>" alt="#">
                                </div>
                                <h3>Real Estate</h3>
                                <h5 class="total">65</h5>
                            </a>


                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/laptop.svg')); ?>" alt="#">
                                </div>
                                <h3>Education</h3>
                                <h5 class="total">35</h5>
                            </a>


                            <a href="category.html" class="single-cat">
                                <div class="icon">
                                    <img src="<?php echo e(asset('website/assets/images/categories/hospital.svg')); ?>" alt="#">
                                </div>
                                <h3>Health & Beauty</h3>
                                <h5 class="total">22</h5>
                            </a>



                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="items-grid section custom-padding">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2 class="wow fadeInUp" data-wow-delay=".4s">أحدث المطاعم</h2>
                        <p class="wow fadeInUp" data-wow-delay=".6s">لدينا احدث وافضل الوجبات التى تراها من مطاعمنا
                            المختلفة</p>
                    </div>
                </div>
            </div>
            <div class="single-head">
                <div class="row">

                    <?php $__currentLoopData = \App\Models\Resturant::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-12">

                            <div class="single-grid wow fadeInUp" data-wow-delay=".2s">
                                <div class="image">
                                    <a href="<?php echo e(route('resturant.product', $restaurant->id)); ?>" class="thumbnail"><img
                                            src="<?php echo e(asset('storage/' . $restaurant->image)); ?>" alt="#"></a>
                                    <div class="author">
                                        <div class="author-image">
                                            <a href="javascript:void(0)"><img
                                                    src="<?php echo e(asset('website/assets/images/items-grid/author-1.jpg')); ?>"
                                                    alt="#">
                                                <span><?php echo e($restaurant->name); ?></span></a>
                                        </div>
                                        <p class="sale">عرض</p>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="top-content">
                                        <a href="javascript:void(0)" class="tag"><?php echo e($restaurant->name); ?></a>
                                        <h3 class="title">
                                            <a
                                                href="<?php echo e(route('resturant.product', $restaurant->id)); ?>"><?php echo e($restaurant->name); ?></a>
                                        </h3>
                                        <p class="update-time">أخر تحديث :
                                            <?php echo e($restaurant->updated_at->diffForHumans()); ?></p>
                                        <ul class="rating">
                                            <li><i class="lni lni-star-filled"></i></li>
                                            <li><i class="lni lni-star-filled"></i></li>
                                            <li><i class="lni lni-star-filled"></i></li>
                                            <li><i class="lni lni-star-filled"></i></li>
                                            <li><i class="lni lni-star-filled"></i></li>
                                            <li><a href="javascript:void(0)">(35)</a></li>
                                        </ul>
                                        <ul class="info-list">
                                            <li><a href="javascript:void(0)"><i class="lni lni-map-marker"></i> New York,
                                                    US</a></li>
                                            <li><a href="javascript:void(0)"><i class="lni lni-timer"></i> Feb 18,
                                                    2023</a></li>
                                        </ul>
                                    </div>
                                    <div class="bottom-content">
                                        <p class="price">يبدأ من: <span>30 شيكل</span></p>
                                        <a href="javascript:void(0)" class="like"><i
                                                class="lni lni-heart"></i></a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                </div>
            </div>
        </div>
    </section>


    


    <section class="browse-cities section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2 class="wow fadeInUp" data-wow-delay=".4s">مدننا</h2>
                        <p class="wow fadeInUp" data-wow-delay=".6s">لدينا العديد من المطاعم .</p>
                    </div>
                </div>
            </div>
            <div class="row ">

                <?php $__currentLoopData = \App\Models\City::withCount('Resturant')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-12">

                        <div class="single-city wow fadeInUp" data-wow-delay=".2s">
                            <a href="<?php echo e(route('city.resturants' , $city->id)); ?>" class="info-box">
                                <div class="image">
                                    <img src="<?php echo e($city->image); ?>" alt="#">
                                </div>
                                <div class="content">
                                    <h4 class="name">
                                        <?php echo e($city->name); ?>

                                        <span><?php echo e($city->resturant_count); ?> مطاعم</span>
                                    </h4>
                                </div>
                                <div class="more-btn">
                                    <i class="lni lni-circle-plus"></i>
                                </div>
                            </a>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                <div class="col-lg-6 col-md-6 col-12">

                    <div class="single-city wow fadeInUp" data-wow-delay=".2s">
                        <a href="category.html" class="info-box">
                            <div class="image">
                                <img src="assets/images/cities/img4.jpg" alt="#">
                            </div>
                            <div class="content">
                                <h4 class="name">
                                    San Francisco
                                    <span>355 Ads</span>
                                </h4>
                            </div>
                            <div class="more-btn">
                                <i class="lni lni-circle-plus"></i>
                            </div>
                        </a>
                    </div>

                </div>
                <div class="col-lg-6 col-md-6 col-12">

                    <div class="single-city wow fadeInUp" data-wow-delay=".4s">
                        <a href="category.html" class="info-box">
                            <div class="image">
                                <img src="assets/images/cities/img5.jpg" alt="#">
                            </div>
                            <div class="content">
                                <h4 class="name">
                                    Newe Orleans
                                    <span>76 Ads</span>
                                </h4>
                            </div>
                            <div class="more-btn">
                                <i class="lni lni-circle-plus"></i>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>

    


    <section class="items-tab section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2 class="wow fadeInUp" data-wow-delay=".4s">وجبات عشوائية</h2>
                        <p class="wow fadeInUp" data-wow-delay=".6s"></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="nav-latest-tab" data-bs-toggle="tab"
                                data-bs-target="#nav-latest" type="button" role="tab" aria-controls="nav-latest"
                                aria-selected="true">آخر الوجبات</button>
                            <button class="nav-link" id="nav-popular-tab" data-bs-toggle="tab"
                                data-bs-target="#nav-popular" type="button" role="tab" aria-controls="nav-popular"
                                aria-selected="false">الوجبات الشائعة</button>
                            <button class="nav-link" id="nav-random-tab" data-bs-toggle="tab"
                                data-bs-target="#nav-random" type="button" role="tab" aria-controls="nav-random"
                                aria-selected="false">وجبات اخرى</button>
                        </div>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-latest" role="tabpanel"
                            aria-labelledby="nav-latest-tab">
                            <div class="row">

                                <?php $__currentLoopData = \App\Models\Meal::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-md-4 col-12">

                                        <div class="single-item-grid">
                                            <div class="image">
                                                <a href="item-details.html"><img
                                                        src="<?php echo e(asset('storage/' . $pro->image)); ?>" alt="#"></a>
                                                <i class=" cross-badge lni lni-bolt"></i>
                                                <span class="flat-badge sale">Sale</span>
                                            </div>
                                            <div class="content">
                                                <a href="javascript:void(0)" class="tag">Mobile</a>
                                                <h3 class="title">
                                                    <a href="<?php echo e(route('ShowProduct',$pro->id)); ?>"><?php echo e($pro->name); ?></a>
                                                </h3>
                                                <p class="location"><a href="javascript:void(0)"><i
                                                            class="lni lni-map-marker">
                                                        </i>Boston</a></p>
                                                <ul class="info">
                                                    <li class="price"><?php echo e($pro->price); ?></li>
                                                    <li class="like"><a href="javascript:void(0)"><i
                                                                class="lni lni-heart"></i></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-popular" role="tabpanel" aria-labelledby="nav-popular-tab">
                            <div class="row">
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-2.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Others</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Travel Kit</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>San Francisco</a></p>
                                            <ul class="info">
                                                <li class="price">$580.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-3.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Electronic</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Nikon DSLR Camera</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Alaska, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$560.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-1.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Mobile</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Apple Iphone X</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Boston</a></p>
                                            <ul class="info">
                                                <li class="price">$890.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-4.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Furniture</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Poster Paint</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Las Vegas</a></p>
                                            <ul class="info">
                                                <li class="price">$85.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-7.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Electronic</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Cctv camera</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Delhi, India</a></p>
                                            <ul class="info">
                                                <li class="price">$350.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-8.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Mobile</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Samsung Glalaxy S8</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Delaware, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$299.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-5.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Furniture</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Official Metting Chair</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Alaska, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$750.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-6.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge rent">Rent</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Books & Magazine</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Story Book</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>New York, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$120.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-random" role="tabpanel" aria-labelledby="nav-random-tab">
                            <div class="row">
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-3.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Electronic</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Nikon DSLR Camera</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Alaska, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$560.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-4.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Furniture</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Poster Paint</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Las Vegas</a></p>
                                            <ul class="info">
                                                <li class="price">$85.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-5.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Furniture</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Official Metting Chair</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Alaska, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$750.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-1.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Mobile</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Apple Iphone X</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Boston</a></p>
                                            <ul class="info">
                                                <li class="price">$890.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-2.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Others</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Travel Kit</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>San Francisco</a></p>
                                            <ul class="info">
                                                <li class="price">$580.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-6.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge rent">Rent</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Books & Magazine</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Story Book</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>New York, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$120.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-7.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Electronic</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Cctv camera</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Delhi, India</a></p>
                                            <ul class="info">
                                                <li class="price">$350.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-3 col-md-4 col-12">

                                    <div class="single-item-grid">
                                        <div class="image">
                                            <a href="item-details.html"><img src="assets/images/items-tab/item-8.jpg"
                                                    alt="#"></a>
                                            <i class=" cross-badge lni lni-bolt"></i>
                                            <span class="flat-badge sale">Sale</span>
                                        </div>
                                        <div class="content">
                                            <a href="javascript:void(0)" class="tag">Mobile</a>
                                            <h3 class="title">
                                                <a href="item-details.html">Samsung Glalaxy S8</a>
                                            </h3>
                                            <p class="location"><a href="javascript:void(0)"><i
                                                        class="lni lni-map-marker">
                                                    </i>Delaware, USA</a></p>
                                            <ul class="info">
                                                <li class="price">$299.00</li>
                                                <li class="like"><a href="javascript:void(0)"><i
                                                            class="lni lni-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    


    <section class="testimonials section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title align-center gray-bg">
                        <h2 class="wow fadeInUp" data-wow-delay=".4s">ماذا يقول الناس عنا</h2>
                        <p class="wow fadeInUp" data-wow-delay=".6s">هناك العديد من المطاعم لكن كلاسي من المطاعم المميزة</p>
                    </div>
                </div>
            </div>
            <div class="row testimonial-slider">
                <div class="col-lg-4 col-md-6 col-12">

                    <div class="single-testimonial">
                        <div class="quote-icon">
                            <i class="lni lni-quotation"></i>
                        </div>
                        <div class="author">
                            <img src="assets/images/testimonial/testi1.jpg" alt="#">
                            <h4 class="name">
                                ياسمين أحمد
                                <span class="deg">Founder & CEO</span>
                            </h4>
                        </div>
                        <div class="text">
                            <p>‏"إنه لأمر مدهش مدى سهولة التعرف على مطاعم جديدة. لديها وجبات مميزة وطعم لا يقاوم ".‏</p>
                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-6 col-12">

                    <div class="single-testimonial">
                        <div class="quote-icon">
                            <i class="lni lni-quotation"></i>
                        </div>
                        <div class="author">
                            <img src="assets/images/testimonial/testi2.jpg" alt="#">
                            <h4 class="name">
                                محمد أحمد
                                <span class="deg">Web Developer</span>
                            </h4>
                        </div>
                        <div class="text">
                            <p> ‏"إنه لأمر مدهش مدى سهولة التعرف على مطاعم جديدة. لديها وجبات مميزة وطعم لا يقاوم ".‏</p>
                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-6 col-12">

                    <div class="single-testimonial">
                        <div class="quote-icon">
                            <i class="lni lni-quotation"></i>
                        </div>
                        <div class="author">
                            <img src="assets/images/testimonial/testi3.jpg" alt="#">
                            <h4 class="name">
                                سالي خليل
                                <span class="deg">Ui/Ux Designer</span>
                            </h4>
                        </div>
                        <div class="text">
                            <p>‏"إنه لأمر مدهش مدى سهولة التعرف على مطاعم جديدة. لديها وجبات مميزة وطعم لا يقاوم ".‏</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\BestResturantsAroundYou-main\resources\views/website/index.blade.php ENDPATH**/ ?>